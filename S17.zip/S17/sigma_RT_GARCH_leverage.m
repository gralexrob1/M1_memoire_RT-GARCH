
function [sigma_sq_leverage]=sigma_RT_GARCH_leverage(par_vec,y)

%y=vector of data
%par_vec=parameter vector=[alpha beta gamma psi]

n=length(y);
sigma_sq_leverage=zeros(n,1);
sigma_sq_leverage(1)=(par_vec(1)+(2*par_vec(3)+1)*(par_vec(4)+par_vec(5)))/(1-par_vec(2)-par_vec(3));
b=zeros(n,1);
d=zeros(n,1);
term1Log=zeros(n,1);
dLog=zeros(n,1);


for t=2:n
    if y(t)==0
    y(t)=0.01;
    end
  
  b(t)=par_vec(1)+par_vec(2)*sigma_sq_leverage(t-1)+par_vec(3)*(y(t-1)^2);
  term1Log(t)=0.5*log(b(t)*b(t)+4*(y(t)^2)*(par_vec(4)*(sign(y(t))==1|sign(y(t))==0))+4*(y(t)^2)*(par_vec(5)*(sign(y(t))==-1)));
  %d= sqrt((term1-b)/(2*psi));
  dLog(t)=0.5*(log(exp(term1Log(t))-b(t))-log(2*(par_vec(4)*(sign(y(t))==1|sign(y(t))==0)+par_vec(5)*(sign(y(t))==-1))));
  d(t)= sign(y(t))*exp(dLog(t));
  %result= (returns(t)/(d*term1))*normpdf(d,0,1); 
  sigma_sq_leverage(t)=b(t)+(d(t)^2)*(par_vec(4)*(sign(y(t))==1|sign(y(t))==0))+(d(t)^2)*(par_vec(5)*(sign(y(t))==-1));
  
   
end


end