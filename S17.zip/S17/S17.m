%Importation des données

init_date = '1-Jan-1989';
end_date = '1-Apr-2021';

SP = getMarketDataViaYahoo('^GSPC',init_date, end_date, '1d');

Close = SP (:,'Close');         %Extraction des prix à la fermeture 
prices = table2array(Close);    %Changement du format pour pouvoir utiliser Garch
returns = diff(log(prices));    %Calcul des rendements 
date = SP( :,'Date');         %Extraction des dates
dates = table2array(date);    %Changement du format pour pouvoir tracer le graphique 

%Graphique des prix 
%Importation des données

figure 
plot(dates, prices)
title("Prix de l'indice S&P 500 de 1989 à aujourd'hui")

%Graphique des rendements 
figure 
plot(dates(2:end),returns)
title("Rendements de l'indice S&P 500 de 1989 à aujourd'hui")

%Histogramme des rendements 
figure
histogram(returns,50)
title ("Histogramme des rendements de l'indice S&P 500 de 1989 à aujourd'hui")

%Importation des données sur une nouvelle période
%On prend une plus petite periode pour observée l'autocorrélation des
%rendements
init_date_bis = '1-Feb-2012';
end_date_bis = '1-Apr-2012';

SP_bis = getMarketDataViaYahoo('^GSPC',init_date, end_date, '1d');

Close_bis = SP (:,'Close');         %Extraction des prix à la fermeture 
prices_bis = table2array(Close);    %Changement du format pour pouvoir utiliser Garch
returns_bis = diff(log(prices));    %Calcul des rendements 

%Tracé de l'autocorrélation des rendements : 
figure 
autocorr(returns_bis)
title("Auto-corrélation des rendements du S&P500")

%Tracé de l'autocorrélation des rendements carrés : 
squarerets = returns_bis.^2;
figure
autocorr(squarerets)
title ("Auto-corrélation des rendements carrés du S&P500")

%Estimation modèle Garch 
Mdl = garch('GarchLags',1,'ArchLags',1,'Offset',NaN);
EstMdl = estimate(Mdl,returns);
condVar = infer(EstMdl, returns);                   %Calcul de la variance conditionnelle à partir du modèle 
condVol = sqrt(condVar);                            %Calcul de la volatilité 

%Graphique rendements et volatilité estimée 
figure
plot(dates(2:end), returns); hold on
plot(dates(2:end), condVol); hold off 
title ("Rendements et volatilité estimée par le modèle Garch(1,1)")
legend('Rendement','Volatilité estimée','Location','best')

%Prévision de la volatilité à l'aide du modèle Garch
    %Prévision à long terme, au temps t pour le temps t + h 
        %En temps normal : 
%On importe à nouveau les données en s'arrêtant avant la crise du Covid. 
%Importation des données
init_date = '1-Jan-2015';
end_date = '1-Jan-2019';

SP = getMarketDataViaYahoo('^GSPC',init_date, end_date, '1d');
Mdl = garch('GarchLags',1,'ArchLags',1,'Offset',NaN);
Close = SP (:,'Close');
prices = table2array(Close);

returns = diff(log(prices));

EstMdl = estimate(Mdl,returns);

numPeriods = 30;
vF = forecast(EstMdl,numPeriods,returns);
v = infer(EstMdl,returns);
dates_table = SP(:,'Date');
dates = table2array(dates_table);
%Calculer la volatilité à l'aide du modèle garch afin de la comparer avec
%les prévisions
end_date2 = '02-Feb-2019';
SP2 = getMarketDataViaYahoo('^GSPC',init_date, end_date2, '1d');
Close2 = SP2(:,'Close');
prices2 = table2array(Close2);
returns2 =diff(log(prices2));


EstMdl2 = estimate (Mdl, returns2);
v2 = infer (EstMdl2,returns2);
dates_table2 = SP2(:,'Date');
dates2 = table2array(dates_table2);

figure;
plot(dates2(2:end),v2,'k:','LineWidth',2);
hold on;
plot(dates(end):dates(end) + 30,[v(end);vF],'r','LineWidth',2);
title('Prévision de la variance conditionnelle des rendements.');
ylabel('Variance conditionelle');
xlabel('Date');
legend({'Echantillon de la variance conditionnelle estimée','Prévision de la future variance conditionnelle'}, ...
    'Location','Best');

    %En temps de crise : 
    %On prend à nouveau des données différents, on se situe maintenant
    %juste après le début de la crise du Covid 19 
init_date = '1-Jan-2015';
end_date = '1-Mar-2020';

SP = getMarketDataViaYahoo('^GSPC',init_date, end_date, '1d');
Mdl = garch('GarchLags',1,'ArchLags',1,'Offset',NaN);
Close = SP (:,'Close');
prices = table2array(Close);

returns = diff(log(prices));

EstMdl = estimate(Mdl,returns);

numPeriods = 30;
vF = forecast(EstMdl,numPeriods,returns);
v = infer(EstMdl,returns);
dates_table = SP(:,'Date');
dates = table2array(dates_table);
%Calculer la volatilité à l'aide du modèle garch afin de la comparer avec
%les prévisions
end_date2 = '01-Apr-2020';
SP2 = getMarketDataViaYahoo('^GSPC',init_date, end_date2, '1d');
Close2 = SP2(:,'Close');
prices2 = table2array(Close2);
returns2 =diff(log(prices2));


EstMdl2 = estimate (Mdl, returns2);
v2 = infer (EstMdl2,returns2);
dates_table2 = SP2(:,'Date');
dates2 = table2array(dates_table2);

figure;
plot(dates2(2:end),v2,'k:','LineWidth',2);
hold on;
plot(dates(end):dates(end) + 30,[v(end);vF],'r','LineWidth',2);
title('Prévision de la variance conditionnelle des rendements en temps de crise.');
ylabel('Variance conditionelle');
xlabel('Date');
legend({'Echantillon de la variance conditionnelle estimée','Prévision de la future variance conditionnelle'}, ...
    'Location','Best');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% Analyse numérique RT-GARCH %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Importation des données
init_date = '1-Jan-2015';
end_date = '1-Jan-2018';

SP = getMarketDataViaYahoo('^GSPC',init_date, end_date, '1d');

%Calcul des rendements
Close = SP (:,'Close');
prices = table2array(Close);
dates_table = SP(:,'Date');
dates = table2array(dates_table);

n1 = length(prices);
returns = diff(log(prices));


%Calcul des rendements sur la période totale
end_date2 = '1-Jan-2021';
SP2 = getMarketDataViaYahoo('^GSPC',init_date, end_date2, '1d');
Close2 = SP2(:,'Close');
prices2 = table2array(Close2);
dates_table2 = SP2(:,'Date');
dates2 = table2array(dates_table2);

n2 = length(prices2);

returns2 = diff(log(prices2));



%Calcul des paramètres du modèle
options=optimset('MaxFunEvals',10000,'MaxIter',10000);
par_vec = [0,0.7,0.09,0.0000001]; %param d'entrée
neg_loglikelihood3 = @(x)neg_loglikelihood2(x,returns);
param=fminsearch(neg_loglikelihood3, par_vec,options);





%Calcul des paramètres du modèle avec levier

par_vec_lev = [0,0.7,0.06,0.00001,0.00001]; %param d'entrée
neg_loglikelihood_leverage3 = @(x)neg_loglikelihood_leverage2(x,returns);
param_RT_leverage=fminsearch(neg_loglikelihood_leverage3, par_vec_lev,options);



%Calcul des paramètres du modèle avec levier et feedback

par_vec_lev_feed = [0,0.7,0.08,0.00001,0.00001,0]; %param d'entrée
neg_loglikelihood_leverage_feedback3 = @(x)neg_loglikelihood_leverage_feedback2(x,returns);
param_RT_leverage_feedback=fminsearch(neg_loglikelihood_leverage_feedback3, par_vec_lev_feed, options);





% y1 = échantillon d'estimation
% y2 = échantillon pour l'estimation "out-of-sample" 
% xmin1 = paramètres estimés du modèle RT_GACH_Simple 
% xmin2 = paramètres estimés du modèle GARCH(1,1) -N
% xmin5 = paramètres estimés du modèle RT_GARCH model avec levier 
% xmin6 = paramètres estimés du modèle RT_GARCH model with levier et feedback


y1=returns;
y2=returns2;
xmin1=param;
xmin5=param_RT_leverage;
xmin6=param_RT_leverage_feedback;


sigma_sq_1=sigma_RT_GARCH_simple(xmin1,y1);
sigma_sq_leverage=sigma_RT_GARCH_leverage(xmin5,y1);
sigma_sq_leverage_feedback=sigma_RT_GARCH_lev_fed(xmin6,y1);

n=length(y1);
m=length(y2);

%%
Y1=y1;
Y2=y1;
Y3=y1;
Y4=y1;
Y7=y1;


%%
Mdl_1=garch(1,1); % GARCH(1,1)-N

fit1=estimate(Mdl_1,y1);

xmin21=[fit1.Constant,fit1.GARCH,fit1.ARCH];
xmin2=cell2mat(xmin21);

sigma_sq_GARCH=sigma_GARCH(xmin2,y1);

[VV1,K1]=infer(fit1,y1); % garch(1,1)-N 


h=30; %horizon de prédiction


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Prédiction du GARCH(1,1) avec N(0,1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

Forecast_GARCH1=zeros(m-h,1);
Forecast_GARCH_sigma=zeros(m-h,1);

for l=1:m-h
SigmaForecast1= forecast(fit1,h,'Y0',Y4,'V0', VV1);
Forecast_GARCH_sigma(l)=SigmaForecast1(end);    %volatilité prédite
 Y4=[y1;y2(1:l+h-1)];
 VV1=[VV1;Forecast_GARCH_sigma(l)];
end


s22=xmin2(1)/(1-xmin2(2)-xmin2(3));
for l=1:m-h 
    Forecast_GARCH1(l)=s22+((xmin2(2)+xmin2(3))^h)*(sigma_sq_GARCH(end)-s22);  %rendements prédits
    Y7=[y1;y2(1:l+h-1)];
sigma_sq_GARCH=sigma_GARCH(xmin2,Y7);
end



sigma_GARCH1=sigma_GARCH(xmin2,y2);

figure;
plot(dates2(2:m+1),sigma_GARCH1,'k:','LineWidth',2);
hold on;
plot(dates2(2+h:m+1),Forecast_GARCH_sigma,'r','LineWidth',2);
title('Prédiction de la Volatilité par GARCH(1,1)');
ylabel('Volatilité');
xlabel('Temps');
legend({'Estimation de la volatilité','Prédiction de la Volatilité'}, ...
    'Location','Best');




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Prédiction du RT_Garch simple
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


s1=(xmin1(1)+2*xmin1(4)*xmin1(3)+xmin1(4))/(1-(xmin1(2)+xmin1(3)));
lambda=zeros(m-h,1);
Forecast_New_model1=zeros(m-h,1);

for l=1:m-h

lambda(l)=(s1+((xmin1(2)+xmin1(3))^h)*(sigma_sq_1(end)-s1)); %volatilité prédite
Forecast_New_model1(l)=lambda(l)+2*xmin1(4);    %rendements prédits 
Y1=[y1;y2(1:l+h-1)];
sigma_sq_1=sigma_RT_GARCH_simple(xmin1,Y1);
end


sigma_RT=sigma_RT_GARCH_simple(xmin1,y2);

figure;
plot(dates2(2:m+1),sigma_RT,'k:','LineWidth',2);
hold on;
plot(dates2(2+h:m+1),lambda,'r','LineWidth',2);
title('Prédiction de la Volatilité par le RT_Garch simple');
ylabel('Volatilité');
xlabel('Temps');
legend({'Estimation de la volatilité','Prédiction de la Volatilité'}, ...
    'Location','Best');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Prédiction du RT_Garch avec levier
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

s5=(xmin5(1)+(2*xmin5(3)+1)*(xmin5(4)+xmin5(5)))/(1-(xmin5(2)+xmin5(3)));

Forecast_New_model_leverage1=zeros(m-h,1);
lambda_lev=zeros(m-h,1);

for l=1:m-h
    lambda_lev(l)=s5+((xmin5(2)+xmin5(3))^h)*(sigma_sq_leverage(end)-s5); %volatilité prédite
    Forecast_New_model_leverage1(l)=lambda_lev(l)+2*(xmin5(4)+xmin5(5));  %rendements prédits
    Y2=[y1;y2(1:l+h-1)];
    length(Y2);
    sigma_sq_leverage=sigma_RT_GARCH_leverage(xmin5,Y2);
end

sigma_RT_leverage=sigma_RT_GARCH_leverage(xmin5,y2);

figure;
plot(dates2(2:m+1),sigma_RT_leverage,'k:','LineWidth',2);
hold on;
plot(dates2(2+h:m+1),lambda_lev,'r','LineWidth',2);
title('Prédiction de la Volatilité par le RT_Garch avec levier');
ylabel('Volatilité');
xlabel('Temps');
legend({'Estimation de la volatilité','Prédiction de la Volatilité'}, ...
    'Location','Best');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Prédiction du RT_Garch simple avec levier et feedback
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

s6=(xmin6(1)+(2*(xmin6(3)+xmin6(4))+1)*(xmin6(5)+xmin6(6)))/(1-xmin6(2)-xmin6(3)-xmin6(4));

Forecast_leverage_feedback1=zeros(m-h,1);
lambda_lev_feed=zeros(m-h,1);

for l=1:m-h

    lambda_lev_feed(l)=s6+((xmin6(2)+xmin6(3)+xmin6(4))^h)*(sigma_sq_leverage_feedback(end)-s6);%volatilité prédite
    Forecast_leverage_feedback1(l)=lambda_lev_feed(l)+2*(xmin6(5)+xmin6(6)); %rendements prédits
    Y3=[y1;y2(1:l+h-1)];
    sigma_sq_leverage_feedback=sigma_RT_GARCH_lev_fed(xmin6,Y3);
end

sigma_RT_leverage_feed=sigma_RT_GARCH_lev_fed(xmin6,y2);


figure;
plot(dates2(2:m+1),sigma_RT_leverage_feed,'k:','LineWidth',2);
hold on;
plot(dates2(2+h:m+1),lambda_lev_feed,'r','LineWidth',2);
title('Prédiction de la Volatilité par le RT_Garch avec levier et feedback');
ylabel('Volatilité');
xlabel('Temps');
legend({'Estimation de la volatilité','Prédiction de la Volatilité'}, ...
    'Location','Best');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plot des rendements et volatilité

sigma2_RT=zeros(m,1);
for l=1:m
    sigma2_RT(l)=sqrt(sigma_RT(l));
end

    
figure;
plot(returns2); hold on
plot(sigma2_RT); hold off 
title ("Rendements et Volatilité estimée")
legend('Rendements','Volatilité estimée','Location','best')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MSE_2

Loss1=zeros(m-h,1);
Loss1_leverage=zeros(m-h,1);
Loss1_leverage_feedback=zeros(m-h,1);
Loss2=zeros(m-h,1);

for l=3:m-h
Loss1(l)=(sigma_GARCH1(l)-lambda(l))^2;
Loss1_leverage(l)=(sigma_RT_leverage(l)-lambda_lev(l))^2;
Loss1_leverage_feedback(l)=(sigma_RT_leverage_feed(l)-lambda_lev_feed(l))^2;
Loss2(l)=(sigma_GARCH1(l)-Forecast_GARCH_sigma(l))^2;
end

MSE_2_1=sum(Loss1)/(m-h);
MSE_2_leverage=sum(Loss1_leverage)/(m-h);
MSE_2_leverage_feedback=sum(Loss1_leverage_feedback)/(m-h);
MSE_2_2=sum(Loss2)/(m-h);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%QLIKE
L1=zeros(m-h,1);
L1_Leverage=zeros(m-h,1);
L1_Leverage_feedback=zeros(m-h,1);
L2=zeros(m-h,1);

for l=3:m-h
L1(l)=log(lambda(l))+(sigma_RT(l)/lambda(l));
L1_Leverage(l)=log(lambda_lev(l))+(sigma_RT_leverage(l)/lambda_lev(l));
L1_Leverage_feedback(l)=log(lambda_lev_feed(l))+(sigma_RT_leverage_feed(l)/lambda_lev_feed(l));
L2(l)=log(Forecast_GARCH_sigma(l))+(sigma_GARCH1(l)/Forecast_GARCH_sigma(l));

end


QLIKE_1=sum(L1)/(m-h);
QLIKE_1_leverage=sum(L1_Leverage)/(m-h);
QLIKE_1_leverage_feedback=sum(L1_Leverage_feedback)/(m-h);
QLIKE_2=sum(L2)/(m-h);




%% niveau de la Value at Risk

p=0.05;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Value at risk
[flog_leverage,sigma_sq_leverage, log_f, d, term1Log]=neg_loglikelihood_leverage(xmin5,y1);
[flog_1,sigma_sq_GARCH]=neg_loglikelihood_GARCH(xmin2,y1);


f_leverage=exp(-flog_leverage);
f_1=exp(-flog_1);

L_VaR_New_model=zeros(m-h,1);
L_VaR_leverage=zeros(m-h,1);
L_VaR_leverage_feedback=zeros(m-h,1);
L_VaR_GARCH=zeros(m-h,1);



for l=1:m-h
L_VaR_New_model(l)=1.96*(sqrt(lambda(l)));
L_VaR_leverage(l)=1.96*(sqrt(Forecast_New_model_leverage1(l)));
L_VaR_leverage_feedback(l)=1.96*(sqrt(Forecast_leverage_feedback1(l)));
L_VaR_GARCH(l)=1.96*(sqrt(Forecast_GARCH1(l)));

end
                                             
VaR_New_model=sum(L_VaR_New_model)/(m-h);
VaR_leverage=sum(L_VaR_leverage)/(m-h);
VaR_leverage_feedback=sum(L_VaR_leverage_feedback)/(m-h);
VaR_GARCH=sum(L_VaR_GARCH)/(m-h);


%Calcul du ratio "pertes supérieures à la VaR/pertes attendues"
z=length(y2);


Violations_New_model=zeros(z,1);
Violations_leverage=zeros(z,1);
Violations_leverage_feedback=zeros(z,1);
Violations_GARCH=zeros(z,1);

for i=1:z
    
 if y2(i)<= -VaR_New_model
     Violations_New_model(i)=1;
 end
 
 if y2(i)<= -VaR_leverage
     Violations_leverage(i)=1;
 end
 
 if y2(i)<= -VaR_leverage_feedback
     Violations_leverage_feedback(i)=1;
 end
 

 
 if y2(i)<= -VaR_GARCH
     Violations_GARCH(i)=1;
 end
 


 

end

VR_RT_simple=sum(Violations_New_model)/(p*z);
VR_RT_lev=sum(Violations_leverage)/(p*z);
VR_RT_lev_feed=sum(Violations_leverage_feedback)/(p*z);
VR_Garch=sum(Violations_GARCH)/(p*z);



%% Hansen's SPA test and Model confidence set for MSE loss function
c = bsds(Loss1,[Loss1_leverage_feedback,Loss1_leverage,Loss2], 1000, 12,'STUDENTIZED','BLOCK');
c_lev = bsds(Loss1_leverage,[Loss1_leverage_feedback,Loss2,Loss1], 1000, 12,'STUDENTIZED','BLOCK');
c_lev_feed = bsds(Loss1_leverage_feedback,[Loss1_leverage,Loss2,Loss1], 1000, 12,'STUDENTIZED','BLOCK');
c_GA = bsds(Loss2,[Loss1_leverage_feedback,Loss1_leverage,Loss1], 1000, 12,'STUDENTIZED','BLOCK');
 
%% Hansen's SPA test and Model confidence set for QLIKE loss function
c1 = bsds(L1,[L1_Leverage_feedback,L1_Leverage,L2], 1000, 12,'STUDENTIZED','BLOCK') ; 
c1_lev = bsds(L1_Leverage,[L1_Leverage_feedback,L2,L1], 1000, 12,'STUDENTIZED','BLOCK') ;
c1_lev_feed = bsds(L1_Leverage_feedback,[L1_Leverage,L2,L1], 1000, 12,'STUDENTIZED','BLOCK') ; 
c1_GA = bsds(L2,[L1_Leverage_feedback,L1_Leverage,L1], 1000, 12,'STUDENTIZED','BLOCK') ;


