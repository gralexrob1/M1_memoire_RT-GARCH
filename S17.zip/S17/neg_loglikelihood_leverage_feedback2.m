function negloglike_leverage_feedback=neg_loglikelihood_leverage_feedback2(par_vec,y)

%y=vector of data
%par_vec=parameter vector=[alpha beta gamma psi]

n=length(y);
sigma_sq_leverage_feedback=zeros(n,1);
sigma_sq_leverage_feedback(1)=(par_vec(1)+(2*(par_vec(3)+par_vec(4))+1)*(par_vec(5)+par_vec(6)))/(1-par_vec(2)-par_vec(3)-par_vec(4));
b=zeros(n,1);
d=zeros(n,1);
term1Log=zeros(n,1);
dLog=zeros(n,1);


%for t=2:n
    
   %b(t)=par_vec(1)+par_vec(2)*sigma_sq_1(t-1)+par_vec(3)*(y(t-1)^2);
    %coeff1(t)=sqrt((b(t)^2)+4*par_vec(4)*(y(t)^2));
    %d(t)=sign(y(t))*sqrt((coeff1(t)-b(t))/(2*par_vec(4)));
    %sigma_sq_1(t)=b(t)+par_vec(4)*(d(t)^2);
%end

log_f=zeros(n,1);
for t=2:n
    if y(t)==0
    y(t)=0.01;
    end
  
  b(t)=par_vec(1)+par_vec(2)*sigma_sq_leverage_feedback(t-1)+par_vec(3)*(y(t-1)^2)*(sign(y(t))==1|sign(y(t))==0)+par_vec(4)*(y(t-1)^2)*(sign(y(t))==-1);
  term1Log(t)=0.5*log(b(t)*b(t)+4*(y(t)^2)*(par_vec(5)*(sign(y(t))==1|sign(y(t))==0))+4*(y(t)^2)*(par_vec(6)*(sign(y(t))==-1)));
  %d= sqrt((term1-b)/(2*psi));
  dLog(t)=0.5*(log(exp(term1Log(t))-b(t))-log(2*(par_vec(5)*(sign(y(t))==1|sign(y(t))==0)+par_vec(6)*(sign(y(t))==-1))));
  d(t)= sign(y(t))*exp(dLog(t));
  %result= (returns(t)/(d*term1))*normpdf(d,0,1); 
  sigma_sq_leverage_feedback(t)=b(t)+(d(t)^2)*(par_vec(5)*(sign(y(t))==1|sign(y(t))==0))+(d(t)^2)*(par_vec(6)*(sign(y(t))==-1));
  
   %log_f(t)=log(abs(y(t)))-dLog(t)-term1Log(t)-0.5*(d(t)^2);
   
   log_f(t)=log((y(t))/d(t))-term1Log(t)+log(normpdf(d(t)));
   
  %% log_f(t)=log((y(t))/d(t))-term1Log(t)-0.5*(d(t)^2);
   
   %log_f(t)=log(abs(y(t)))-0.5*(log(b(t)*b(t)+4*(y(t)^2)*par_vec(4)))-log(d(t))-0.5*log(2*pi)-0.5*d(t)*d(t);
end

 
%for t=2:n
 %   log_f(t)=log(abs(y(t)))-log(coeff1(t))-log(abs(d(t)))-0.5*log(2*pi)-0.5*(d(t)^2);
%end


%negloglike_leverage=-sum(log_f)+(n-1)*0.5*log(2*pi);

negloglike_leverage_feedback=-sum(log_f);

%else   
%negloglike=100000000000000000;    
%end

if ~isfinite(negloglike_leverage_feedback)
  negloglike_leverage_feedback=n^10;
end

end