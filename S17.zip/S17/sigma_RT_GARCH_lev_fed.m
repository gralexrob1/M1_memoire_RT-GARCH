function [sigma_sq_leverage_feedback]=sigma_RT_GARCH_lev_fed(par_vec,y)


n=length(y);
sigma_sq_leverage_feedback=zeros(n,1);
sigma_sq_leverage_feedback(1)=(par_vec(1)+(2*(par_vec(3)+par_vec(4))+1)*(par_vec(5)+par_vec(6)))/(1-par_vec(2)-par_vec(3)-par_vec(4));
b=zeros(n,1);
d=zeros(n,1);
term1Log=zeros(n,1);
dLog=zeros(n,1);


for t=2:n
    if y(t)==0
    y(t)=0.01;
    end
  
  b(t)=par_vec(1)+par_vec(2)*sigma_sq_leverage_feedback(t-1)+par_vec(3)*(y(t-1)^2)*(sign(y(t))==1|sign(y(t))==0)+par_vec(4)*(y(t-1)^2)*(sign(y(t))==-1);
  term1Log(t)=0.5*log(b(t)*b(t)+4*(y(t)^2)*(par_vec(5)*(sign(y(t))==1|sign(y(t))==0))+4*(y(t)^2)*(par_vec(6)*(sign(y(t))==-1)));
  %d= sqrt((term1-b)/(2*psi));
  dLog(t)=0.5*(log(exp(term1Log(t))-b(t))-log(2*(par_vec(5)*(sign(y(t))==1|sign(y(t))==0)+par_vec(6)*(sign(y(t))==-1))));
  d(t)= sign(y(t))*exp(dLog(t));
  %result= (returns(t)/(d*term1))*normpdf(d,0,1); 
  sigma_sq_leverage_feedback(t)=b(t)+(d(t)^2)*(par_vec(5)*(sign(y(t))==1|sign(y(t))==0))+(d(t)^2)*(par_vec(6)*(sign(y(t))==-1));
  
   
  
end

end