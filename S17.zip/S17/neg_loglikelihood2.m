
function negloglike = neg_loglikelihood2(par_vec,y)
    
%y=vector of data
%par_vec=parameter vector=[alpha beta gamma psi]

n=length(y);
sigma_sq_1=zeros(n,1);
sigma_sq_1(1)=(par_vec(1)+2*par_vec(3)*par_vec(4)+par_vec(4))/(1-par_vec(2)-par_vec(3));
b=zeros(n,1);
d=zeros(n,1);
term1Log=zeros(n,1);
dLog=zeros(n,1);


%for t=2:n
    
   %b(t)=par_vec(1)+par_vec(2)*sigma_sq_1(t-1)+par_vec(3)*(y(t-1)^2);
    %coeff1(t)=sqrt((b(t)^2)+4*par_vec(4)*(y(t)^2));
    %d(t)=sign(y(t))*sqrt((coeff1(t)-b(t))/(2*par_vec(4)));
    %sigma_sq_1(t)=b(t)+par_vec(4)*(d(t)^2);
%end

log_f=zeros(n,1);

for t=2:n
    if y(t)==0
    y(t)=0.0001;
    end
  
  b(t)=par_vec(1)+par_vec(2)*sigma_sq_1(t-1)+par_vec(3)*(y(t-1)^2);
  term1Log(t)=0.5*log(b(t)*b(t)+4*par_vec(4)*(y(t)^2));
  %d= sqrt((term1-b)/(2*psi));
  dLog(t)=0.5*(log(exp(term1Log(t))-b(t))-log(2*par_vec(4)));
  d(t)= sign(y(t))*exp(dLog(t));
  %result= (returns(t)/(d*term1))*normpdf(d,0,1); 
  sigma_sq_1(t)=b(t)+par_vec(4)*(d(t)^2);
  
  % log_f(t)=log(abs(y(t)))-dLog(t)-term1Log(t)-0.5*(d(t)^2);
  log_f(t)=log((y(t))/d(t))-term1Log(t)+log(normpdf(d(t)));
   
   %log_f(t)=log(abs(y(t)))-0.5*(log(b(t)*b(t)+4*(y(t)^2)*par_vec(4)))-log(d(t))-0.5*log(2*pi)-0.5*d(t)*d(t);
end

 
%for t=2:n
 %   log_f(t)=log(abs(y(t)))-log(coeff1(t))-log(abs(d(t)))-0.5*log(2*pi)-0.5*(d(t)^2);
%end


negloglike=-sum(log_f);



%else   
%negloglike=100000000000000000;    
%end

if ~isfinite(negloglike)
  negloglike=n^10;
end

end