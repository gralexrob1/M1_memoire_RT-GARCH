function [negloglike,sigma_sq_GARCH,e]=neg_loglikelihood_GARCH(par,y)
%y=vector of data
%par=parameter vector=[alpha beta gamma]
n=length(y);
sigma_sq_GARCH=zeros(n,1);
sigma_sq_GARCH(1)=par(1)/(1-par(2)-par(3));
e=zeros(n,1);



log_f=zeros(n,1);

for t=2:n
    %if y(t)==0
    %y(t)=0.00001;
    %end
  
   sigma_sq_GARCH(t)=par(1)+par(2)*sigma_sq_GARCH(t-1)+par(3)*(y(t-1)^2);
   
  log_f(t)= -0.5*(log(sigma_sq_GARCH(t)))-(0.5*((y(t)^2)/(sigma_sq_GARCH(t))));
  
  e(t)=y(t)/(sqrt(sigma_sq_GARCH(t)));
end


 
negloglike=-sum(log_f)+n*0.5*log(2*pi);


if ~isfinite(negloglike)
  negloglike=n^10;
end


end