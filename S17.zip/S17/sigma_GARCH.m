function [sigma_sq_GARCH]=sigma_GARCH(par,y)
%y=vector of data
%par=parameter vector=[alpha beta gamma]
n=length(y);
sigma_sq_GARCH=zeros(n,1);
sigma_sq_GARCH(1)=par(1)/(1-par(2)-par(3));



for t=2:n
    if y(t)==0
    y(t)=0.00001;
    end
  
   sigma_sq_GARCH(t)=par(1)+par(2)*sigma_sq_GARCH(t-1)+par(3)*(y(t-1)^2);
 
end

end